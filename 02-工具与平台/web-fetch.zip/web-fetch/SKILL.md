---
name: web-fetch
description: Fetch and extract readable content from a URL (HTML → markdown/text). Use for lightweight page access without browser automation.
---

# Web Fetch
Use command-line (terminal) tools (e.g., curl) to fetch web page content. After reading, analyze and identify useful, readable content, then organize it into markdown format for the user.

# Main Process
1. Use the information in `<system_information>` to understand the user's operating system and shell type.
2. Based on the OS and shell type, use terminal tools to execute the correct command-line commands to retrieve the webpage content.
3. Carefully read the HTML code of the webpage, analyze the readable parts, and filter out content unrelated to the user's question.
4. Output the useful content to the user in markdown format.

# On Windows
On Windows, curl may not be available by default. In such cases, it is recommended to use native .NET methods to access web pages.
example: $wc = New-Object System.Net.WebClient; $wc.Encoding = [System.Text.Encoding]::UTF8; $wc.DownloadString('https://www.baidu.com')

# Troubleshooting
- You may encounter a lack of necessary tools in the system. First, try using different tools. If that doesn’t work, attempt to help the user install curl.
- The output should preserve the original language of the content. Do not translate it.
- You must consider encoding issues, as the user is likely accessing Chinese websites.
